<?php
require 'db.php';
require 'auth.php';
$_SESSION['flash_errore'] = 'modulo whatsapp rimosso';
header('Location: clienti.php');
exit;
