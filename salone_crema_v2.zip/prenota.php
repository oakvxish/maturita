<?php
require_once __DIR__ . '/db.php';

$salone_id = (int) ($_GET['id'] ?? $_POST['salone_id'] ?? 0);
$salone = null;

if ($salone_id > 0) {
    $salone = $conn->query("SELECT id, nome_salone FROM saloni WHERE id=$salone_id LIMIT 1")->fetch_assoc();
}

if (!$salone) {
    http_response_code(404);
    ?>
    <!DOCTYPE html>
    <html lang="it">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>prenotazione</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
        

<style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    html { -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }
    body {
        font-family: 'Inter', Arial, sans-serif;
        background: radial-gradient(circle at top left, rgba(107,79,211,.08), transparent 28%), linear-gradient(180deg, #fbf6ef 0%, #f5ecdf 100%);
        color: #2b2235;
        min-height: 100vh;
    }
    .box, .panel, .form-card {
        background: linear-gradient(180deg, rgba(255,253,248,.97) 0%, rgba(248,242,232,.94) 100%);
        border: 1px solid #e7dccd;
        border-radius: 28px;
        box-shadow: 0 18px 48px rgba(56,41,95,.08);
    }
    .eyebrow, label {
        font-size: .7rem;
        text-transform: uppercase;
        letter-spacing: .14em;
        color: #7d6f8f;
        font-weight: 700;
    }
    h1 {
        font-size: 2rem;
        line-height: 1;
        font-weight: 800;
        letter-spacing: -.05em;
        margin-bottom: 10px;
    }
    p, .sub, .meta { color: #7d6f8f; line-height: 1.6; }
    input, select, textarea {
        width: 100%;
        min-height: 46px;
        padding: 12px 14px;
        border: 1px solid #e2d6ca;
        border-radius: 14px;
        background: #fffdf8;
        color: #2b2235;
        font-size: .95rem;
        font-family: inherit;
    }
    input:focus, select:focus, textarea:focus {
        outline: none;
        border-color: rgba(107,79,211,.45);
        box-shadow: 0 0 0 4px rgba(107,79,211,.08);
    }
    button, .btn {
        min-height: 46px;
        padding: 12px 16px;
        border: 0;
        border-radius: 999px;
        background: linear-gradient(180deg, #6b4fd3 0%, #5036b3 100%);
        color: #fff;
        font-family: inherit;
        font-size: .9rem;
        font-weight: 700;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 14px 30px rgba(80,54,179,.18);
    }
    .err {
        margin-bottom: 16px;
        padding: 12px 14px;
        border-radius: 14px;
        border: 1px solid #f1cfd7;
        background: #fbecef;
        color: #a44d5a;
    }
    .ok {
        margin-bottom: 16px;
        padding: 12px 14px;
        border-radius: 14px;
        border: 1px solid #cfe4d7;
        background: #ecf5ef;
        color: #3f7a63;
    }
</style>


    </head>
    <body>
        <div class="box">
            <div class="eyebrow">prenotazione</div>
            <h1>ID salone non valido</h1>
            <p>Inserisci un ID salone valido, ad esempio <strong>prenota.php?id=1</strong>.</p>
            <form method="get">
                <label>id salone</label>
                <input type="number" name="id" min="1" required>
                <button type="submit">apri prenotazione</button>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit;
}

$sid = (int) $salone['id'];
$nome_salone = htmlspecialchars($salone['nome_salone']);
$servizi = [];
$resultServizi = $conn->query("SELECT id, nome, categoria, durata_minuti, prezzo FROM servizi WHERE salone_id=$sid ORDER BY categoria, nome");
if ($resultServizi) {
    while ($row = $resultServizi->fetch_assoc()) {
        $servizi[] = $row;
    }
}

$errore = '';
$successo = false;
$nome = trim($_POST['_nome'] ?? '');
$cognome = trim($_POST['_cognome'] ?? '');
$telefono = trim($_POST['_telefono'] ?? '');
$email = trim($_POST['_email'] ?? '');
$svid = (int) ($_POST['servizio_id'] ?? 0);
$data_raw = trim($_POST['_data'] ?? '');
$ora = trim($_POST['_ora'] ?? '');
$note = trim($_POST['note'] ?? '');
$servizio_out = '';
$data_fmt = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($nome === '' || $cognome === '' || $svid <= 0 || $data_raw === '') {
        $errore = 'compila i campi obbligatori';
    } else {
        $srv = $conn->query("SELECT id, nome FROM servizi WHERE id=$svid AND salone_id=$sid")->fetch_assoc();
        if (!$srv) {
            $errore = 'servizio non valido';
        } else {
            $n = $conn->real_escape_string($nome);
            $co = $conn->real_escape_string($cognome);
            $te = $conn->real_escape_string($telefono);
            $em = $conn->real_escape_string($email);
            $no = $conn->real_escape_string($note);
            $cliente = null;

            if ($telefono !== '') {
                $cliente = $conn->query("SELECT id FROM clienti WHERE salone_id=$sid AND telefono='$te' LIMIT 1")->fetch_assoc();
            }
            if (!$cliente && $email !== '') {
                $cliente = $conn->query("SELECT id FROM clienti WHERE salone_id=$sid AND email='$em' LIMIT 1")->fetch_assoc();
            }

            if ($cliente) {
                $cid = (int) $cliente['id'];
                $conn->query("UPDATE clienti SET nome='$n', cognome='$co', telefono='$te', email='$em', note='$no' WHERE id=$cid AND salone_id=$sid");
            } else {
                $conn->query("INSERT INTO clienti (salone_id,nome,cognome,telefono,email,note) VALUES ($sid,'$n','$co','$te','$em','$no')");
                $cid = (int) $conn->insert_id;
            }

            $ora_sql = $ora !== '' ? $ora . ':00' : '09:00:00';
            $data_ora = $conn->real_escape_string($data_raw . ' ' . $ora_sql);
            $conn->query("INSERT INTO appuntamenti (salone_id,cliente_id,servizio_id,data_ora,stato,note) VALUES ($sid,$cid,$svid,'$data_ora','attesa','$no')");

            $successo = true;
            $servizio_out = htmlspecialchars($srv['nome']);
            $ts = strtotime($data_raw);
            $giorni = ['domenica','lunedì','martedì','mercoledì','giovedì','venerdì','sabato'];
            $mesi = ['','gennaio','febbraio','marzo','aprile','maggio','giugno','luglio','agosto','settembre','ottobre','novembre','dicembre'];
            $data_fmt = $giorni[(int) date('w', $ts)] . ' ' . date('j', $ts) . ' ' . $mesi[(int) date('n', $ts)] . ' ' . date('Y', $ts);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Prenota - <?php echo $nome_salone ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>

        * { box-sizing: border-box; margin: 0; padding: 0; }
        html {
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        body {
            font-family: 'Manrope', Arial, Helvetica, sans-serif;
            background:
                radial-gradient(circle at top left, rgba(127,98,70,.08), transparent 30%),
                radial-gradient(circle at top right, rgba(255,255,255,.72), transparent 24%),
                linear-gradient(180deg, #f6f2ec 0%, #f2ede6 100%);
            color: #171512;
        }
        .hero {
            min-height: 300px;
            background: linear-gradient(rgba(16,14,12,.42), rgba(16,14,12,.54)), url('WIN_20260221_12_32_37_Pro.jpg') center/cover no-repeat;
            display: flex;
            align-items: flex-end;
            box-shadow: inset 0 -80px 120px rgba(0,0,0,.10);
        }
        .hero-inner {
            max-width: 1120px;
            width: 100%;
            margin: 0 auto;
            padding: 34px 24px 32px;
        }
        .hero-head {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 16px;
        }
        .hero-mark {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px solid rgba(255,255,255,.18);
            border-radius: 14px;
            background: linear-gradient(180deg, rgba(255,255,255,.16) 0%, rgba(255,255,255,.07) 100%);
            color: #f3ece3;
            backdrop-filter: blur(10px);
            box-shadow: inset 0 1px 0 rgba(255,255,255,.24), 0 14px 30px rgba(0,0,0,.16);
        }
        .hero-label {
            font-size: .7rem;
            text-transform: uppercase;
            letter-spacing: .18em;
            color: #f1e7d8;
        }
        .hero h1 {
            font-family: 'Cormorant Garamond', Georgia, serif;
            font-size: clamp(2.8rem, 6vw, 4.6rem);
            font-weight: 500;
            color: #fff;
            line-height: .95;
            max-width: 640px;
            text-shadow: 0 10px 24px rgba(0,0,0,.16);
        }
        .page {
            max-width: 1120px;
            margin: 0 auto;
            padding: 28px 24px 68px;
        }
        .grid {
            display: grid;
            grid-template-columns: 1.12fr .88fr;
            gap: 20px;
        }
        .card {
            background: linear-gradient(180deg, rgba(255,255,255,.96) 0%, rgba(249,244,238,.92) 100%);
            border: 1px solid #e4dbcf;
            border-radius: 30px;
            padding: 30px;
            box-shadow: inset 0 1px 0 rgba(255,255,255,.75), 0 24px 70px rgba(21, 16, 12, .10), 0 10px 24px rgba(21, 16, 12, .05);
            backdrop-filter: blur(10px);
        }
        .eyebrow {
            font-size: .7rem;
            text-transform: uppercase;
            letter-spacing: .18em;
            color: #6f685f;
            margin-bottom: 12px;
        }
        .card h2,
        .card h3 {
            font-family: 'Cormorant Garamond', Georgia, serif;
            font-size: 2.4rem;
            font-weight: 500;
            line-height: .96;
            margin-bottom: 10px;
        }
        .card p,
        .card li,
        .service-meta,
        .summary,
        .sub,
        .msg {
            color: #6f685f;
            line-height: 1.75;
        }
        .service-list {
            display: grid;
            gap: 12px;
        }
        .service-item {
            padding: 16px 18px;
            border: 1px solid #e7ded1;
            border-radius: 18px;
            background: linear-gradient(180deg, #fffdfa 0%, #f7f1e9 100%);
            box-shadow: inset 0 1px 0 rgba(255,255,255,.9), 0 8px 18px rgba(21,16,12,.04);
        }
        .service-name {
            font-weight: 700;
            color: #171512;
            margin-bottom: 4px;
        }
        .service-meta {
            font-size: .9rem;
        }
        label {
            display: block;
            margin-bottom: 6px;
            font-size: .72rem;
            text-transform: uppercase;
            letter-spacing: .16em;
            color: #6f685f;
            font-weight: 700;
        }
        input,
        select,
        textarea {
            width: 100%;
            padding: 14px 16px;
            border: 1px solid #d8cfc2;
            border-radius: 16px;
            margin-bottom: 14px;
            font-size: .95rem;
            font-family: inherit;
            background: linear-gradient(180deg, #fffdfa 0%, #f7f1e9 100%);
            box-shadow: inset 0 1px 0 rgba(255,255,255,.9), 0 6px 14px rgba(21,16,12,.04);
        }
        input:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: #7f6246;
            box-shadow: inset 0 1px 0 rgba(255,255,255,.9), 0 0 0 4px rgba(127,98,70,.08);
        }
        textarea {
            min-height: 120px;
            resize: vertical;
        }
        button,
        .btn,
        .nav-back {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 46px;
            padding: 0 18px;
            border-radius: 999px;
            border: 1px solid rgba(0,0,0,.08);
            background: linear-gradient(180deg, #6f543d 0%, #7f6246 100%);
            color: #fff;
            text-decoration: none;
            font-family: inherit;
            font-size: .88rem;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 14px 26px rgba(127,98,70,.20);
        }
        .nav-back {
            background: linear-gradient(180deg, #fffdfa 0%, #f7f1e9 100%);
            color: #171512;
            border-color: #ddd2c5;
            box-shadow: inset 0 1px 0 rgba(255,255,255,.9), 0 10px 20px rgba(21,16,12,.05);
        }
        .ok,
        .err,
        .msg {
            padding: 14px 16px;
            border-radius: 16px;
            margin-bottom: 16px;
            border: 1px solid #e4dbcf;
            box-shadow: inset 0 1px 0 rgba(255,255,255,.6);
        }
        .ok {
            background: linear-gradient(180deg, #eff6f1 0%, #e7f0ea 100%);
            border-color: #cadecf;
            color: #365443;
        }
        .err {
            background: linear-gradient(180deg, #f8eeee 0%, #f2e5e2 100%);
            border-color: #e4c9c4;
            color: #7a4a44;
        }
        .summary {
            padding: 16px 18px;
            border: 1px solid #e7ded1;
            border-radius: 18px;
            background: linear-gradient(180deg, #fffdfa 0%, #f7f1e9 100%);
            box-shadow: inset 0 1px 0 rgba(255,255,255,.9), 0 8px 18px rgba(21,16,12,.04);
        }
        @media (max-width: 920px) {
            .grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="hero">
        <div class="hero-inner">
            <div class="hero-head">
                <div class="hero-mark" aria-hidden="true">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="10" cy="10" r="6.75" stroke="currentColor" stroke-width="1.25"/>
                        <path d="M10 2.75V8.25" stroke="currentColor" stroke-width="1.25" stroke-linecap="round"/>
                    </svg>
                </div>
                <div class="hero-label"><?php echo $nome_salone ?></div>
            </div>
            <h1>Prenota il tuo appuntamento.</h1>
        </div>
    </div>

    <div class="page">
        <?php if ($successo): ?>
            <div class="avviso ok">Richiesta ricevuta. Il tuo appuntamento e stato registrato in attesa di conferma.</div>
        <?php endif; ?>
        <?php if ($errore): ?>
            <div class="avviso err"><?php echo htmlspecialchars($errore) ?></div>
        <?php endif; ?>

        <div class="grid">
            <div class="card">
                <?php if ($successo): ?>
                    <div class="eyebrow">richiesta inviata</div>
                    <h2>Grazie, <?php echo htmlspecialchars($nome) ?>.</h2>
                    <p class="sub">Abbiamo registrato la tua richiesta presso <?php echo $nome_salone ?>. Qui trovi il riepilogo dei dati inviati.</p>
                    <div class="summary">
                        <div><strong>Cliente</strong><br><?php echo htmlspecialchars(trim($nome . ' ' . $cognome)) ?></div>
                        <div><strong>Servizio</strong><br><?php echo $servizio_out ?></div>
                        <div><strong>Data</strong><br><?php echo htmlspecialchars($data_fmt ?: '-') ?></div>
                        <div><strong>Orario</strong><br><?php echo htmlspecialchars($ora !== '' ? $ora : '09:00') ?></div>
                        <div><strong>Contatto</strong><br><?php echo htmlspecialchars($telefono !== '' ? $telefono : ($email !== '' ? $email : '-')) ?></div>
                        <div><strong>Note</strong><br><?php echo nl2br(htmlspecialchars($note !== '' ? $note : '-')) ?></div>
                    </div>
                    <div style="margin-top:20px">
                        <a href="prenota.php?id=<?php echo $sid ?>" class="btn alt">nuova prenotazione</a>
                    </div>
                <?php else: ?>
                    <div class="eyebrow">prenotazione online</div>
                    <h2>Compila la richiesta.</h2>
                    <p class="sub">Seleziona il servizio, indica la data desiderata e lascia i tuoi dati. La richiesta verra salvata nel gestionale del salone.</p>
                    <form method="post" action="prenota.php?id=<?php echo $sid ?>">
                        <input type="hidden" name="salone_id" value="<?php echo $sid ?>">
                        <div class="row">
                            <div>
                                <label>nome</label>
                                <input type="text" name="_nome" value="<?php echo htmlspecialchars($nome) ?>" required>
                            </div>
                            <div>
                                <label>cognome</label>
                                <input type="text" name="_cognome" value="<?php echo htmlspecialchars($cognome) ?>" required>
                            </div>
                        </div>
                        <div class="row">
                            <div>
                                <label>telefono</label>
                                <input type="tel" name="_telefono" value="<?php echo htmlspecialchars($telefono) ?>">
                            </div>
                            <div>
                                <label>email</label>
                                <input type="email" name="_email" value="<?php echo htmlspecialchars($email) ?>">
                            </div>
                        </div>
                        <label>servizio</label>
                        <select name="servizio_id" required>
                            <option value="">seleziona</option>
                            <?php foreach ($servizi as $servizio): ?>
                                <option value="<?php echo (int) $servizio['id'] ?>" <?php echo $svid === (int) $servizio['id'] ? 'selected' : '' ?>><?php echo htmlspecialchars($servizio['nome']) ?> - <?php echo (int) $servizio['durata_minuti'] ?> min - €<?php echo number_format((float) $servizio['prezzo'], 2, ',', '.') ?></option>
                            <?php endforeach ?>
                        </select>
                        <div class="row">
                            <div>
                                <label>data</label>
                                <input type="date" name="_data" value="<?php echo htmlspecialchars($data_raw) ?>" required>
                            </div>
                            <div>
                                <label>ora</label>
                                <input type="time" name="_ora" value="<?php echo htmlspecialchars($ora) ?>">
                            </div>
                        </div>
                        <label>note</label>
                        <textarea name="note"><?php echo htmlspecialchars($note) ?></textarea>
                        <button type="submit" class="btn">invia richiesta</button>
                    </form>
                <?php endif; ?>
            </div>

            <div class="card">
                <div class="eyebrow">servizi disponibili</div>
                <h2><?php echo $nome_salone ?></h2>
                <p class="sub">Il link pubblico usa l'id del salone: <strong><?php echo $sid ?></strong>.</p>
                <?php if (!$servizi): ?>
                    <p class="sub">Nessun servizio disponibile al momento.</p>
                <?php else: ?>
                    <div class="service-list">
                        <?php foreach ($servizi as $servizio): ?>
                            <div class="service-item">
                                <div class="service-name"><?php echo htmlspecialchars($servizio['nome']) ?></div>
                                <div class="service-meta"><?php echo htmlspecialchars($servizio['categoria']) ?> · <?php echo (int) $servizio['durata_minuti'] ?> min · €<?php echo number_format((float) $servizio['prezzo'], 2, ',', '.') ?></div>
                            </div>
                        <?php endforeach ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <footer>
        © <?php echo date('Y') ?> <?php echo $nome_salone ?>
    </footer>
</body>
</html>
