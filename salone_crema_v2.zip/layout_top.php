<?php
$tema = 'chiaro';

if (isset($conn) && isset($sid)) {
    $temaResult = $conn->query("SELECT valore FROM impostazioni WHERE chiave='tema' AND salone_id=$sid");
    $temaRow = $temaResult ? $temaResult->fetch_assoc() : null;
    if ($temaRow && !empty($temaRow['valore'])) {
        $tema = $temaRow['valore'];
    }
}

$nome_salone_nav = $_SESSION['nome_salone'] ?? 'salone';
$pagina_corrente = basename($_SERVER['PHP_SELF'], '.php');
$salone_ruolo = normalizza_ruolo($_SESSION['salone_ruolo'] ?? 'dipendente');
$saloni_menu = $_SESSION['saloni_abilitati'] ?? [];
$flash_errore_layout = function_exists('estrai_flash') ? estrai_flash('flash_errore') : '';

$voci_menu = [
    ['file' => 'index.php', 'pagina' => 'index', 'label' => 'dashboard'],
    ['file' => 'appuntamenti.php', 'pagina' => 'appuntamenti', 'label' => 'appuntamenti'],
    ['file' => 'clienti.php', 'pagina' => 'clienti', 'label' => 'clienti'],
    ['file' => 'servizi.php', 'pagina' => 'servizi', 'label' => 'servizi'],
    ['file' => 'magazzino.php', 'pagina' => 'magazzino', 'label' => 'magazzino'],
    ['file' => 'analitiche.php', 'pagina' => 'analitiche', 'label' => 'analitiche'],
    ['file' => 'utenti_salone.php', 'pagina' => 'utenti_salone', 'label' => 'utenti'],
    ['file' => 'impostazioni.php', 'pagina' => 'impostazioni', 'label' => 'impostazioni'],
];
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo htmlspecialchars($nome_salone_nav); ?> - gestionale</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
<style>
/* ════════════════════════════════════════════
   TOKEN DI DESIGN — CREMA MINIMALE
   ════════════════════════════════════════════ */
:root {
    /* sfondo */
    --bg:        <?php echo $tema==='scuro' ? '#16130f' : '#f7f3ec'; ?>;
    --surface:   <?php echo $tema==='scuro' ? '#1e1b16' : '#fdfaf5'; ?>;
    --surface-2: <?php echo $tema==='scuro' ? '#252118' : '#f0ebe1'; ?>;
    --surface-3: <?php echo $tema==='scuro' ? '#2c2820' : '#e6e0d4'; ?>;

    /* testo */
    --text:      <?php echo $tema==='scuro' ? '#ede7dd' : '#1e1a14'; ?>;
    --muted:     <?php echo $tema==='scuro' ? '#8c8070' : '#8a7f70'; ?>;

    /* bordi */
    --border:    <?php echo $tema==='scuro' ? '#2e2a22' : '#ddd6c8'; ?>;
    --border-2:  <?php echo $tema==='scuro' ? '#3a352c' : '#ccc4b4'; ?>;

    /* accento — nero caldo su crema, crema su scuro */
    --ink:       <?php echo $tema==='scuro' ? '#ede7dd' : '#1e1a14'; ?>;
    --ink-inv:   <?php echo $tema==='scuro' ? '#16130f' : '#f7f3ec'; ?>;

    /* semantici */
    --ok:      #3d7558;
    --warn:    #7a5c18;
    --danger:  #8c3a48;

    /* forma */
    --r-sm: 6px;
    --r-md: 10px;
    --r-lg: 14px;
    --r-xl: 18px;

    /* ombra unica, leggerissima */
    --shadow: 0 1px 3px rgba(0,0,0,.07), 0 4px 12px rgba(0,0,0,.04);
}

/* ── reset ── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { font-size: 16px; -webkit-font-smoothing: antialiased; }
body {
    font-family: 'Inter', system-ui, sans-serif;
    background: var(--bg);
    color: var(--text);
    line-height: 1.55;
    min-height: 100vh;
}
a { color: inherit; }
img { display: block; max-width: 100%; }

/* ── struttura ── */
.app-shell {
    display: grid;
    grid-template-columns: 220px 1fr;
    min-height: 100vh;
}
.sidebar {
    background: var(--surface);
    border-right: 1px solid var(--border);
    padding: 20px 14px;
    position: sticky;
    top: 0;
    height: 100vh;
    overflow-y: auto;
    display: flex;
    flex-direction: column;
    gap: 0;
}
.main {
    padding: 28px 32px;
    min-width: 0;
}

/* ── brand ── */
.brand {
    display: flex;
    align-items: center;
    gap: 10px;
    padding-bottom: 20px;
    border-bottom: 1px solid var(--border);
    margin-bottom: 20px;
}
.brand-mark {
    width: 32px;
    height: 32px;
    border-radius: var(--r-sm);
    border: 1px solid var(--border);
    background: var(--surface-2);
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--muted);
    flex-shrink: 0;
}
.brand-name { font-size: .9rem; font-weight: 600; }
.brand-sub  { font-size: .7rem; color: var(--muted); margin-top: 1px; }

/* ── tenant box ── */
.tenant-box {
    border: 1px solid var(--border);
    border-radius: var(--r-md);
    padding: 10px;
    background: var(--surface-2);
    margin-bottom: 16px;
}
.tenant-box label { font-size: .65rem; text-transform: uppercase; letter-spacing: .1em; color: var(--muted); font-weight: 600; margin-bottom: 6px; }
.tenant-actions { display: grid; grid-template-columns: 1fr auto; gap: 6px; align-items: center; }
.tenant-role { font-size: .78rem; color: var(--muted); margin-top: 6px; }

/* ── nav ── */
.sidebar nav {
    display: flex;
    flex-direction: column;
    gap: 1px;
    flex: 1;
}
.sidebar nav a {
    display: block;
    padding: 8px 10px;
    border-radius: var(--r-sm);
    font-size: .87rem;
    font-weight: 500;
    color: var(--muted);
    text-decoration: none;
    transition: color .12s, background .12s;
}
.sidebar nav a:hover { color: var(--text); background: var(--surface-2); }
.sidebar nav a.attivo { color: var(--text); background: var(--surface-3); font-weight: 600; }

.sidebar-bottom {
    margin-top: auto;
    padding-top: 16px;
    border-top: 1px solid var(--border);
}
.sidebar-bottom a { font-size: .83rem; color: var(--muted); text-decoration: none; }
.sidebar-bottom a:hover { color: var(--text); }

/* ── topbar ── */
.topbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 12px;
    margin-bottom: 28px;
    padding-bottom: 16px;
    border-bottom: 1px solid var(--border);
}
.topbar-title {
    font-size: .68rem;
    text-transform: uppercase;
    letter-spacing: .12em;
    font-weight: 600;
    color: var(--muted);
}
.topbar-link {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    height: 34px;
    padding: 0 13px;
    border-radius: 999px;
    border: 1px solid var(--border);
    background: var(--surface);
    font-size: .82rem;
    font-weight: 500;
    text-decoration: none;
    color: var(--text);
    transition: background .12s;
}
.topbar-link:hover { background: var(--surface-2); }

/* ── intestazione pagina ── */
.page-head { margin-bottom: 24px; }
.titolo-pagina {
    font-size: 1.6rem;
    font-weight: 700;
    letter-spacing: -.03em;
    line-height: 1.1;
    margin-bottom: 6px;
}
.page-intro { font-size: .9rem; color: var(--muted); max-width: 640px; }

/* ── label e etichette generiche ── */
label,
th,
.metric-label,
.section-kicker,
.eyebrow,
.muted-caps,
.card h3 {
    font-size: .66rem;
    text-transform: uppercase;
    letter-spacing: .11em;
    font-weight: 600;
    color: var(--muted);
}
label { display: block; margin-bottom: 6px; }

/* ── griglie ── */
.metric-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 12px; margin-bottom: 16px; }
.griglia-2   { display: grid; grid-template-columns: repeat(2,1fr); gap: 12px; margin-bottom: 16px; }
.griglia-3   { display: grid; grid-template-columns: repeat(3,1fr); gap: 12px; margin-bottom: 16px; }
.griglia-4   { display: grid; grid-template-columns: repeat(4,1fr); gap: 12px; margin-bottom: 16px; }
.riga-form   { display: grid; grid-template-columns: repeat(2,1fr); gap: 12px; margin-bottom: 16px; }
.quick-grid  { display: grid; grid-template-columns: repeat(3,1fr); gap: 12px; margin-bottom: 16px; }

/* ── card / metric / superficie ── */
.card,
.metric,
.toolbar-form,
.empty-state,
.surface-soft {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--r-lg);
    box-shadow: var(--shadow);
}
.card        { padding: 18px; }
.metric      { padding: 16px; }
.toolbar-form { padding: 14px; }
.surface-soft { padding: 14px; }
.empty-state  { padding: 20px; }

.metric-value {
    font-size: 1.9rem;
    font-weight: 700;
    letter-spacing: -.05em;
    line-height: 1;
    margin-top: 8px;
}
.metric-note,
.metric-label + *,
.card p,
.helper-text,
.info-soft,
.table-secondary { font-size: .86rem; color: var(--muted); }

.card-title-row { display: flex; justify-content: space-between; align-items: flex-end; gap: 12px; margin-bottom: 14px; }
.card-title-strong { font-size: .95rem; font-weight: 600; }

.quick-link {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 6px;
    padding: 16px;
    min-height: 80px;
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--r-lg);
    box-shadow: var(--shadow);
    text-decoration: none;
    color: var(--text);
    transition: background .12s;
}
.quick-link:hover { background: var(--surface-2); }
.quick-link strong { font-size: .92rem; font-weight: 600; }

.empty-state strong { display: block; font-size: .9rem; font-weight: 600; margin-bottom: 4px; }
.empty-state p { color: var(--muted); font-size: .87rem; margin-bottom: 12px; }

/* ── stacks ── */
.stack-sm > * + * { margin-top: 6px; }
.stack-md > * + * { margin-top: 12px; }
.stack-lg > * + * { margin-top: 20px; }

/* ── tabella ── */
table { width: 100%; border-collapse: collapse; }
th { padding: 8px 10px 10px; border-bottom: 1px solid var(--border-2); text-align: left; }
td { padding: 11px 10px; border-bottom: 1px solid var(--border); text-align: left; vertical-align: middle; font-size: .9rem; }
tbody tr:hover td { background: var(--surface-2); }
tr:last-child td { border-bottom: none; }
.table-wrap { overflow-x: auto; }

/* ── badge ── */
.badge {
    display: inline-flex;
    align-items: center;
    height: 22px;
    padding: 0 8px;
    border-radius: 4px;
    font-size: .62rem;
    text-transform: uppercase;
    letter-spacing: .09em;
    font-weight: 600;
    border: 1px solid transparent;
}
.badge-vip, .badge-attesa, .badge-proprietario      { background: #ede7db; border-color: #d8cfc0; color: #5a4830; }
.badge-normale, .badge-completato, .badge-dipendente { background: #deeee6; border-color: #bfdbcc; color: #2d6044; }
.badge-potenziale, .badge-confermato                 { background: #f0e8d4; border-color: #ddd0b0; color: #6a5010; }
.badge-inattivo, .badge-annullato                    { background: #f0e0e4; border-color: #dcc4ca; color: #7a2e3a; }

/* ── bottoni ── */
.btn,
.btn-primary,
.btn-grigio,
.btn-pericolo,
.btn-ghost {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    height: 38px;
    padding: 0 16px;
    border-radius: 999px;
    border: 1px solid transparent;
    font-size: .86rem;
    font-weight: 600;
    font-family: inherit;
    cursor: pointer;
    text-decoration: none;
    transition: background .12s, border-color .12s, color .12s;
    white-space: nowrap;
}
.btn,
.btn-primary {
    background: var(--ink);
    color: var(--ink-inv);
    border-color: var(--ink);
}
.btn:hover, .btn-primary:hover {
    opacity: .85;
}
.btn-grigio,
.btn-ghost {
    background: var(--surface);
    color: var(--text);
    border-color: var(--border);
}
.btn-grigio:hover, .btn-ghost:hover { background: var(--surface-2); }
.btn-pericolo { background: var(--danger); color: #fff; border-color: var(--danger); }
.btn-pericolo:hover { opacity: .85; }
.btn-piccolo { height: 30px; padding: 0 11px; font-size: .76rem; }

/* ── form ── */
form input,
form select,
form textarea,
.tenant-box select {
    display: block;
    width: 100%;
    min-height: 42px;
    padding: 9px 12px;
    border: 1px solid var(--border);
    border-radius: var(--r-md);
    background: var(--surface);
    color: var(--text);
    font-size: .9rem;
    font-family: inherit;
    margin-bottom: 12px;
    transition: border-color .12s;
    appearance: none;
}
form input:focus,
form select:focus,
form textarea:focus,
.tenant-box select:focus {
    outline: none;
    border-color: var(--border-2);
    box-shadow: 0 0 0 3px rgba(0,0,0,.05);
}
form textarea { min-height: 96px; resize: vertical; }

.toolbar-row { display: grid; grid-template-columns: 1fr auto auto; gap: 10px; align-items: end; }
.toolbar-actions { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }

/* ── avvisi ── */
.avviso {
    padding: 11px 14px;
    border-radius: var(--r-md);
    border: 1px solid var(--border);
    font-size: .88rem;
    margin-bottom: 14px;
}
.avviso-ok  { background: #dff0e7; border-color: #b8d9c6; color: #2d6044; }
.avviso-err { background: #f0dee2; border-color: #dbbfc5; color: #7a2e3a; }

/* ── barra progresso ── */
.barra-prog {
    width: 100%;
    height: 5px;
    border-radius: 999px;
    background: var(--surface-3);
    overflow: hidden;
}
.barra-prog-fill {
    height: 100%;
    background: var(--ink);
    border-radius: 999px;
}

/* ── lista inline ── */
.list-inline { display: flex; flex-wrap: wrap; gap: 8px; }

/* ── utilità spaziatura ── */
.text-right { text-align: right; }
.mb-0  { margin-bottom: 0 !important; }
.mt-8  { margin-top:  8px; }
.mt-12 { margin-top: 12px; }
.mt-16 { margin-top: 16px; }
.mt-20 { margin-top: 20px; }

/* ── responsive ── */
@media (max-width: 1080px) {
    .app-shell { grid-template-columns: 1fr; }
    .sidebar { position: static; height: auto; border-right: none; border-bottom: 1px solid var(--border); }
    .metric-grid, .griglia-4, .quick-grid { grid-template-columns: repeat(2,1fr); }
}
@media (max-width: 720px) {
    .main { padding: 16px; }
    .metric-grid,
    .griglia-2, .griglia-3, .griglia-4,
    .riga-form, .quick-grid,
    .toolbar-row, .tenant-actions { grid-template-columns: 1fr; }
    .topbar { flex-wrap: wrap; }
    .titolo-pagina { font-size: 1.35rem; }
    table { min-width: 640px; }
}
</style>

</head>
<body>
<div class="app-shell">
    <aside class="sidebar">
        <div class="brand">
            <div class="brand-mark" aria-hidden="true">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 3.5C7.85786 3.5 4.5 6.85786 4.5 11C4.5 15.1421 7.85786 18.5 12 18.5C16.1421 18.5 19.5 15.1421 19.5 11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    <path d="M12 6V11L15.5 13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </div>
            <div>
                <div class="brand-name"><?php echo htmlspecialchars($nome_salone_nav); ?></div>
                <div class="brand-sub">gestionale salone</div>
            </div>
        </div>

        <?php if ($saloni_menu): ?>
            <div class="tenant-box">
                <form method="post">
                    <input type="hidden" name="azione_globale" value="cambia_salone">
                    <label for="salone_id">salone attivo</label>
                    <div class="tenant-actions">
                        <select name="salone_id" id="salone_id">
                            <?php foreach ($saloni_menu as $saloneItem): ?>
                                <option value="<?php echo (int) $saloneItem['salone_id']; ?>" <?php echo (int) $saloneItem['salone_id'] === (int) $sid ? 'selected' : ''; ?>><?php echo htmlspecialchars($saloneItem['nome_salone']); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn btn-grigio btn-piccolo">cambia</button>
                    </div>
                    <div class="tenant-role">ruolo: <?php echo htmlspecialchars($salone_ruolo); ?></div>
                </form>
            </div>
        <?php endif; ?>

        <nav>
            <?php foreach ($voci_menu as $voce): ?>
                <?php if (utente_puo_vedere_pagina($voce['pagina'], $salone_ruolo)): ?>
                    <a href="<?php echo $voce['file']; ?>" class="<?php echo $pagina_corrente === $voce['pagina'] ? 'attivo' : ''; ?>"><?php echo htmlspecialchars($voce['label']); ?></a>
                <?php endif; ?>
            <?php endforeach; ?>
        </nav>

        <div class="sidebar-bottom">
            <a href="logout.php">esci</a>
        </div>
    </aside>

    <main class="main">
        <div class="topbar">
            <div class="topbar-title">area riservata</div>
            <a class="topbar-link" href="prenota.php?id=<?php echo (int) $sid; ?>" target="_blank">apri pagina prenotazione</a>
        </div>
        <?php if ($flash_errore_layout): ?>
            <div class="avviso avviso-err"><?php echo htmlspecialchars($flash_errore_layout); ?></div>
        <?php endif; ?>
