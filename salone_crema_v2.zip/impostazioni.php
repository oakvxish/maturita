<?php
require 'db.php';
require 'auth.php';

$messaggio = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $campi = ['nome_salone', 'iva', 'valuta', 'tema'];
    foreach ($campi as $k) {
        $chiave = $conn->real_escape_string($k);
        $val = $conn->real_escape_string(trim($_POST[$k] ?? ''));
        $conn->query("INSERT INTO impostazioni (salone_id,chiave,valore) VALUES ($sid,'$chiave','$val') ON DUPLICATE KEY UPDATE valore='$val'");
    }

    $nome_salone = trim($_POST['nome_salone'] ?? '');
    $_SESSION['nome_salone'] = $nome_salone;
    $nome_salone_sql = $conn->real_escape_string($nome_salone);
    $conn->query("UPDATE saloni SET nome_salone='$nome_salone_sql' WHERE id=$sid");
    $messaggio = 'impostazioni salvate';
}

$cfg = [];
$resultCfg = $conn->query("SELECT chiave,valore FROM impostazioni WHERE salone_id=$sid");
if ($resultCfg) {
    while ($r = $resultCfg->fetch_assoc()) {
        $cfg[$r['chiave']] = $r['valore'];
    }
}

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
$basePath = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
if ($basePath === '.' || $basePath === '/') {
    $basePath = '';
}
$link_pub = $scheme . '://' . $_SERVER['HTTP_HOST'] . $basePath . '/prenota.php?id=' . (int) $sid;

require 'layout_top.php';
?>

<div class="page-head">
    <div class="titolo-pagina">impostazioni</div>
    <div class="page-intro">Pochi parametri centrali, link pubblico sempre pronto e tema uniforme. Questa pagina raccoglie le impostazioni che servono davvero all’operatività del salone.</div>
</div>

<?php if ($messaggio): ?><div class="avviso avviso-ok"><?php echo $messaggio ?></div><?php endif ?>

<div class="griglia-2">
    <div class="card">
        <div class="card-title-row">
            <div>
                <div class="eyebrow">generali</div>
                <div class="card-title-strong">profilo salone</div>
            </div>
        </div>
        <form method="post">
            <label>nome salone</label>
            <input type="text" name="nome_salone" value="<?php echo htmlspecialchars($cfg['nome_salone'] ?? ($_SESSION['nome_salone'] ?? '')) ?>">
            <div class="riga-form">
                <div>
                    <label>aliquota iva (%)</label>
                    <input type="number" name="iva" min="0" max="100" step="0.5" value="<?php echo htmlspecialchars($cfg['iva'] ?? '22') ?>">
                </div>
                <div>
                    <label>valuta</label>
                    <select name="valuta">
                        <?php foreach (['EUR','USD','GBP','CHF'] as $v): ?>
                            <option value="<?php echo $v ?>" <?php echo ($cfg['valuta'] ?? 'EUR') === $v ? 'selected' : '' ?>><?php echo $v ?></option>
                        <?php endforeach ?>
                    </select>
                </div>
            </div>
            <label>tema interfaccia</label>
            <select name="tema">
                <option value="chiaro" <?php echo ($cfg['tema'] ?? 'chiaro') === 'chiaro' ? 'selected' : '' ?>>chiaro</option>
                <option value="scuro" <?php echo ($cfg['tema'] ?? '') === 'scuro' ? 'selected' : '' ?>>scuro</option>
            </select>
            <button type="submit" class="btn">salva impostazioni</button>
        </form>
    </div>

    <div class="card">
        <div class="card-title-row">
            <div>
                <div class="eyebrow">prenotazione online</div>
                <div class="card-title-strong">link pubblico del salone</div>
            </div>
        </div>
        <label>id salone</label>
        <input type="text" value="<?php echo (int) $sid ?>" readonly>
        <label>link diretto</label>
        <textarea rows="4" readonly><?php echo htmlspecialchars($link_pub) ?></textarea>
        <div class="surface-soft">
            <p>La pagina pubblica usa l’id del salone. Il link è pronto per essere copiato e condiviso senza altre configurazioni.</p>
        </div>
    </div>
</div>

<?php require 'layout_bottom.php'; ?>
