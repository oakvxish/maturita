<?php
session_start();
require_once __DIR__ . '/db.php';

if (!empty($_SESSION['logged_in']) && !empty($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

function normalizza_ruolo_login(?string $ruolo): string
{
    if ($ruolo === 'proprietario') {
        return 'proprietario';
    }
    return 'dipendente';
}

$errore = '';
$nome_salone = 'salone';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identificativo = trim($_POST['identificativo'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($identificativo === '' || $password === '') {
        $errore = 'inserisci tutti i campi';
    } else {
        $stmt = $conn->prepare("SELECT id, username, email, password FROM userdata WHERE username = ? OR email = ? LIMIT 1");
        $stmt->bind_param('ss', $identificativo, $identificativo);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result ? $result->fetch_assoc() : null;
        $stmt->close();

        if ($user && password_verify($password, $user['password'])) {
            $userId = (int) $user['id'];
            $saloni = [];
            $sqlSaloni = "
                SELECT
                    us.salone_id,
                    us.ruolo,
                    us.attivo,
                    s.nome_salone
                FROM user_saloni us
                JOIN saloni s ON s.id = us.salone_id
                WHERE us.user_id = $userId
                  AND us.attivo = 1
                ORDER BY (us.ruolo = 'proprietario') DESC, s.nome_salone ASC
            ";
            $resultSaloni = $conn->query($sqlSaloni);

            if ($resultSaloni) {
                while ($row = $resultSaloni->fetch_assoc()) {
                    $row['ruolo'] = normalizza_ruolo_login($row['ruolo'] ?? 'dipendente');
                    $saloni[] = $row;
                }
            }

            if (!$saloni) {
                $errore = 'nessun salone attivo associato a questo account';
            } else {
                $saloneCorrente = $saloni[0];
                session_regenerate_id(true);
                $_SESSION['logged_in'] = true;
                $_SESSION['user_id'] = $userId;
                $_SESSION['username'] = $user['username'];
                $_SESSION['salone_id'] = (int) $saloneCorrente['salone_id'];
                $_SESSION['nome_salone'] = $saloneCorrente['nome_salone'];
                $_SESSION['salone_ruolo'] = $saloneCorrente['ruolo'];
                $_SESSION['saloni_abilitati'] = $saloni;
                header('Location: index.php');
                exit;
            }
        } else {
            $errore = 'credenziali non valide';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>accesso</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
<style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    html { -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }
    body {
        font-family: 'Inter', Arial, sans-serif;
        background: radial-gradient(circle at top left, rgba(107,79,211,.08), transparent 28%), linear-gradient(180deg, #fbf6ef 0%, #f5ecdf 100%);
        color: #2b2235;
        min-height: 100vh;
    }
    .wrap { width: 100%; max-width: 480px; margin: 0 auto; padding: 32px 20px; }
    .card, .box { background: linear-gradient(180deg, rgba(255,253,248,.96) 0%, rgba(248,242,232,.94) 100%); border: 1px solid #e7dccd; border-radius: 28px; padding: 28px; box-shadow: 0 18px 48px rgba(56,41,95,.08); }
    .brand { display: flex; align-items: center; gap: 12px; margin-bottom: 18px; }
    .brand-mark { width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; border: 1px solid #e7dccd; border-radius: 14px; background: #fffdf8; color: #6b4fd3; box-shadow: 0 10px 26px rgba(56,41,95,.08); flex-shrink: 0; }
    .brand-name { font-size: 1rem; font-weight: 700; letter-spacing: -.02em; }
    .brand-sub, .eyebrow, label { font-size: .7rem; text-transform: uppercase; letter-spacing: .14em; color: #7d6f8f; font-weight: 700; }
    h1 { font-size: 2rem; line-height: 1; font-weight: 800; letter-spacing: -.05em; margin-bottom: 10px; }
    .sub, p { color: #7d6f8f; line-height: 1.6; }
    .sub { margin-bottom: 22px; max-width: 360px; }
    form { margin-top: 18px; }
    .field { margin-bottom: 14px; }
    label { display: block; margin-bottom: 6px; }
    .field input, input, select, textarea { width: 100%; min-height: 46px; padding: 12px 14px; border: 1px solid #e2d6ca; border-radius: 14px; background: #fffdf8; color: #2b2235; font-size: .95rem; font-family: inherit; }
    .field input:focus, input:focus, select:focus, textarea:focus { outline: none; border-color: rgba(107,79,211,.45); box-shadow: 0 0 0 4px rgba(107,79,211,.08); }
    .btn, button { width: 100%; min-height: 46px; padding: 12px 16px; background: linear-gradient(180deg, #6b4fd3 0%, #5036b3 100%); border: 0; border-radius: 999px; color: #fff; cursor: pointer; font-size: .9rem; font-family: inherit; font-weight: 700; box-shadow: 0 14px 30px rgba(80,54,179,.18); }
    .err { margin-bottom: 16px; padding: 12px 14px; border: 1px solid #f1cfd7; border-radius: 14px; background: #fbecef; color: #a44d5a; font-size: .9rem; }
    .ok, .successo { margin-bottom: 16px; padding: 12px 14px; border: 1px solid #cfe4d7; border-radius: 14px; background: #ecf5ef; color: #3f7a63; font-size: .9rem; }
    .footer { margin-top: 18px; padding-top: 16px; border-top: 1px solid #eee3d7; font-size: .9rem; color: #7d6f8f; }
    .footer a, a { color: #5036b3; text-decoration: none; }
    @media (max-width: 640px) { .wrap { padding: 18px 14px; } .card, .box { padding: 22px; border-radius: 22px; } h1 { font-size: 1.7rem; } }
</style>

</head>
<body>
    <div class="wrap">
        <div class="card">
            <div class="brand">
                <div class="brand-mark" aria-hidden="true">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="10" cy="10" r="6.75" stroke="currentColor" stroke-width="1.25"/>
                        <path d="M10 2.75V8.25" stroke="currentColor" stroke-width="1.25" stroke-linecap="round"/>
                    </svg>
                </div>
                <div class="eyebrow">area riservata</div>
            </div>
            <h1><?php echo htmlspecialchars($nome_salone); ?></h1>
            <p class="sub">Accedi al gestionale con le credenziali del tuo account.</p>
            <?php if ($errore): ?>
                <div class="err"><?php echo htmlspecialchars($errore); ?></div>
            <?php endif; ?>
            <form method="post">
                <div class="field">
                    <label>username o email</label>
                    <input type="text" name="identificativo" required autofocus>
                </div>
                <div class="field">
                    <label>password</label>
                    <input type="password" name="password" required>
                </div>
                <button type="submit" class="btn">accedi</button>
            </form>
            <div class="footer">
                <a href="registrazione.php">Crea un nuovo salone</a>
            </div>
        </div>
    </div>
</body>
</html>
