<?php
session_start();
require_once __DIR__ . '/db.php';

$errore = '';
$successo = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $nome_salone = trim($_POST['nome_salone'] ?? '');

    if ($username === '' || $password === '' || $nome_salone === '') {
        $errore = 'tutti i campi sono obbligatori';
    } else {
        $slug_base = strtolower((string) preg_replace('/[^a-z0-9]+/i', '-', $nome_salone));
        $slug_base = trim($slug_base, '-');
        if ($slug_base === '') {
            $slug_base = 'salone';
        }

        $slug = $slug_base;
        $n = 1;
        while ($conn->query("SELECT id FROM saloni WHERE slug='" . $conn->real_escape_string($slug) . "'")->num_rows > 0) {
            $slug = $slug_base . '-' . $n;
            $n++;
        }

        $chk = $conn->prepare('SELECT id FROM userdata WHERE username = ? LIMIT 1');
        $chk->bind_param('s', $username);
        $chk->execute();
        $chk->store_result();

        if ($chk->num_rows > 0) {
            $errore = 'username gia in uso';
            $chk->close();
        } else {
            $chk->close();
            $conn->begin_transaction();

            try {
                $stmtSalone = $conn->prepare('INSERT INTO saloni (nome_salone, slug) VALUES (?, ?)');
                $stmtSalone->bind_param('ss', $nome_salone, $slug);
                $stmtSalone->execute();
                $salone_id = (int) $conn->insert_id;
                $stmtSalone->close();

                $hash = password_hash($password, PASSWORD_DEFAULT);
                $stmtUtente = $conn->prepare('INSERT INTO userdata (username, password, salone_id) VALUES (?, ?, ?)');
                $stmtUtente->bind_param('ssi', $username, $hash, $salone_id);
                $stmtUtente->execute();
                $user_id = (int) $conn->insert_id;
                $stmtUtente->close();

                $stmtPivot = $conn->prepare('INSERT INTO user_saloni (user_id, salone_id, ruolo, attivo) VALUES (?, ?, ?, 1)');
                $ruolo = 'proprietario';
                $stmtPivot->bind_param('iis', $user_id, $salone_id, $ruolo);
                $stmtPivot->execute();
                $stmtPivot->close();

                $impostazioni = [
                    ['nome_salone', $nome_salone],
                    ['iva', '22'],
                    ['valuta', 'EUR'],
                    ['tema', 'chiaro'],
                ];

                $stmtCfg = $conn->prepare('INSERT INTO impostazioni (salone_id, chiave, valore) VALUES (?, ?, ?)');
                foreach ($impostazioni as $impostazione) {
                    $chiave = $impostazione[0];
                    $valore = $impostazione[1];
                    $stmtCfg->bind_param('iss', $salone_id, $chiave, $valore);
                    $stmtCfg->execute();
                }
                $stmtCfg->close();

                $conn->commit();
                $successo = 'salone creato correttamente. ora puoi accedere.';
            } catch (Throwable $e) {
                $conn->rollback();
                $errore = 'errore durante la registrazione';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>registra salone</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
<style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    html { -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }
    body {
        font-family: 'Inter', Arial, sans-serif;
        background: radial-gradient(circle at top left, rgba(107,79,211,.08), transparent 28%), linear-gradient(180deg, #fbf6ef 0%, #f5ecdf 100%);
        color: #2b2235;
        min-height: 100vh;
    }
    .wrap { width: 100%; max-width: 480px; margin: 0 auto; padding: 32px 20px; }
    .card, .box { background: linear-gradient(180deg, rgba(255,253,248,.96) 0%, rgba(248,242,232,.94) 100%); border: 1px solid #e7dccd; border-radius: 28px; padding: 28px; box-shadow: 0 18px 48px rgba(56,41,95,.08); }
    .brand { display: flex; align-items: center; gap: 12px; margin-bottom: 18px; }
    .brand-mark { width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; border: 1px solid #e7dccd; border-radius: 14px; background: #fffdf8; color: #6b4fd3; box-shadow: 0 10px 26px rgba(56,41,95,.08); flex-shrink: 0; }
    .brand-name { font-size: 1rem; font-weight: 700; letter-spacing: -.02em; }
    .brand-sub, .eyebrow, label { font-size: .7rem; text-transform: uppercase; letter-spacing: .14em; color: #7d6f8f; font-weight: 700; }
    h1 { font-size: 2rem; line-height: 1; font-weight: 800; letter-spacing: -.05em; margin-bottom: 10px; }
    .sub, p { color: #7d6f8f; line-height: 1.6; }
    .sub { margin-bottom: 22px; max-width: 360px; }
    form { margin-top: 18px; }
    .field { margin-bottom: 14px; }
    label { display: block; margin-bottom: 6px; }
    .field input, input, select, textarea { width: 100%; min-height: 46px; padding: 12px 14px; border: 1px solid #e2d6ca; border-radius: 14px; background: #fffdf8; color: #2b2235; font-size: .95rem; font-family: inherit; }
    .field input:focus, input:focus, select:focus, textarea:focus { outline: none; border-color: rgba(107,79,211,.45); box-shadow: 0 0 0 4px rgba(107,79,211,.08); }
    .btn, button { width: 100%; min-height: 46px; padding: 12px 16px; background: linear-gradient(180deg, #6b4fd3 0%, #5036b3 100%); border: 0; border-radius: 999px; color: #fff; cursor: pointer; font-size: .9rem; font-family: inherit; font-weight: 700; box-shadow: 0 14px 30px rgba(80,54,179,.18); }
    .err { margin-bottom: 16px; padding: 12px 14px; border: 1px solid #f1cfd7; border-radius: 14px; background: #fbecef; color: #a44d5a; font-size: .9rem; }
    .ok, .successo { margin-bottom: 16px; padding: 12px 14px; border: 1px solid #cfe4d7; border-radius: 14px; background: #ecf5ef; color: #3f7a63; font-size: .9rem; }
    .footer { margin-top: 18px; padding-top: 16px; border-top: 1px solid #eee3d7; font-size: .9rem; color: #7d6f8f; }
    .footer a, a { color: #5036b3; text-decoration: none; }
    @media (max-width: 640px) { .wrap { padding: 18px 14px; } .card, .box { padding: 22px; border-radius: 22px; } h1 { font-size: 1.7rem; } }
</style>

</head>
<body>
    <div class="wrap">
        <div class="card">
            <div class="brand">
                <div class="brand-mark" aria-hidden="true">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="10" cy="10" r="6.75" stroke="currentColor" stroke-width="1.25"/>
                        <path d="M10 2.75V8.25" stroke="currentColor" stroke-width="1.25" stroke-linecap="round"/>
                    </svg>
                </div>
                <div class="eyebrow">nuovo account</div>
            </div>
            <h1>Crea il tuo salone</h1>
            <p class="sub">Genera il salone, il proprietario e le impostazioni iniziali in pochi passaggi.</p>
            <?php if ($errore): ?>
                <div class="err"><?php echo htmlspecialchars($errore); ?></div>
            <?php endif; ?>
            <?php if ($successo): ?>
                <div class="msg"><?php echo htmlspecialchars($successo); ?></div>
            <?php endif; ?>
            <form method="post">
                <div class="field">
                    <label>nome salone</label>
                    <input type="text" name="nome_salone" required>
                </div>
                <div class="field">
                    <label>username proprietario</label>
                    <input type="text" name="username" required>
                </div>
                <div class="field">
                    <label>password</label>
                    <input type="password" name="password" required>
                </div>
                <button type="submit" class="btn">registra salone</button>
            </form>
            <div class="footer">
                <a href="login.php">Hai gia un account? Accedi</a>
            </div>
        </div>
    </div>
</body>
</html>
